console.log("Welcome to Cosmic Horoscopes! 🌟Discover your destiny today.");

//alert("Welcome to Cosmic Horoscopes! 🌟Discover your destiny today.");

//document.write("Welcome to Cosmic Horoscopes! 🌟Discover your destiny today.")
